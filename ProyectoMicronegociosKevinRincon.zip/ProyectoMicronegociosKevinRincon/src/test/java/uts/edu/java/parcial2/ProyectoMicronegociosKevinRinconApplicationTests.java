package uts.edu.java.parcial2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoMicronegociosKevinRinconApplicationTests {

	@Test
	void contextLoads() {
	}

}
