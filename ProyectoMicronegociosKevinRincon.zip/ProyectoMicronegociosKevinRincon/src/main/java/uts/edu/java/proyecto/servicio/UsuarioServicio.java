package uts.edu.java.proyecto.servicio;

import uts.edu.java.proyecto.dto.RegistroDTO;
import uts.edu.java.proyecto.modelo.Rol;
import uts.edu.java.proyecto.modelo.Usuario;
import uts.edu.java.proyecto.repositorio.RolRepositorio;
import uts.edu.java.proyecto.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UsuarioServicio implements UserDetailsService {

    @Autowired private UsuarioRepositorio usuarioRepositorio;
    @Autowired private RolRepositorio     rolRepositorio;
    @Autowired private PasswordEncoder   passwordEncoder;

    // ── UserDetailsService (usado por Spring Security al hacer login) ───────
    @Override
    public UserDetails loadUserByUsername(String correo) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepositorio.findByCorreo(correo)
            .orElseThrow(() -> new UsernameNotFoundException(
                "No existe ningún usuario con el correo: " + correo));

        // Spring Security espera "ROLE_<NOMBRE>" como prefijo de autoridad
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority(
            "ROLE_" + usuario.getRol().getNombre()   // Ej: ROLE_ADMINISTRADOR
        );

        return new User(
            usuario.getCorreo(),
            usuario.getContrasena(),
            usuario.getActivo(),  // enabled
            true,                  // accountNonExpired
            true,                  // credentialsNonExpired
            true,                  // accountNonLocked
            List.of(authority)
        );
    }

    // ── Registro de nuevo usuario ──────────────────────────────────────────
    /**
     * Crea un nuevo usuario a partir del DTO de registro.
     * Asigna automáticamente el rol CAJERO (rol por defecto para auto-registro).
     * El Administrador puede cambiar el rol desde el módulo de gestión de usuarios.
     */
    public void registrar(RegistroDTO dto) {
        Rol rolCajero = rolRepositorio.findByNombre("CAJERO")
            .orElseThrow(() -> new RuntimeException(
                "Rol CAJERO no encontrado. Verifica que la BD tenga los datos iniciales."));

        Usuario nuevo = new Usuario();
        nuevo.setNombre(dto.getNombre());
        nuevo.setCorreo(dto.getCorreo());
        nuevo.setContrasena(passwordEncoder.encode(dto.getContrasena())); // hash bcrypt
        nuevo.setTelefono(dto.getTelefono());
        nuevo.setActivo(true);
        nuevo.setFechaRegistro(LocalDateTime.now());
        nuevo.setRol(rolCajero);

        usuarioRepositorio.save(nuevo);
    }

    // ── Utilidades ────────────────────────────────────────────────────────
    public boolean existeCorreo(String correo) {
        return usuarioRepositorio.existsByCorreo(correo);
    }
}
