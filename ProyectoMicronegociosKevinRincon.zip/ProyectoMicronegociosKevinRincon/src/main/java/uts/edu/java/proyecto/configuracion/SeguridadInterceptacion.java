package uts.edu.java.proyecto.configuracion;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import uts.edu.java.proyecto.modelo.Usuario;

@Component
public class SeguridadInterceptacion implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        String uri = request.getRequestURI();

        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return false;
        }

        String nombreRol = usuario.getRol().getNombre(); // "ADMINISTRADOR", "CAJERO" o "REPARTIDOR"

        // Restricción: Solo el Administrador entra a gestionar usuarios y ver reportes/cierres
        if ((uri.contains("/usuarios") || uri.contains("/cierres") || uri.contains("/reportes")) 
                && !nombreRol.equals("ADMINISTRADOR")) {
            response.sendRedirect(request.getContextPath() + "/dashboard?error=NoAutorizado");
            return false;
        }
        
        // Restricción: Módulo de domicilios habilitado para ADMINISTRADOR y REPARTIDOR
        if (uri.contains("/pedidos") && !(nombreRol.equals("ADMINISTRADOR") || nombreRol.equals("REPARTIDOR"))) {
            response.sendRedirect(request.getContextPath() + "/dashboard?error=NoAutorizado");
            return false;
        }

        return true; 
    }
}