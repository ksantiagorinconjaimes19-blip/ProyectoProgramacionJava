package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepositorio extends JpaRepository<Usuario, Integer> {

    /** Busca un usuario por su correo electrónico (usado por Spring Security). */
    Optional<Usuario> findByCorreo(String correo);

    /** Verifica si ya existe un usuario con ese correo (para evitar duplicados). */
    boolean existsByCorreo(String correo);
}
