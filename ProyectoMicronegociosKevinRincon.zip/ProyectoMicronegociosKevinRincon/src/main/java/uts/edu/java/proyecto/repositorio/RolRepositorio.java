package uts.edu.java.proyecto.repositorio;

import uts.edu.java.proyecto.modelo.Rol; 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository; 
import java.util.Optional;

@Repository
public interface RolRepositorio extends JpaRepository<Rol, Integer> {

    /** Busca un rol por su nombre exacto (ej. "CAJERO", "ADMINISTRADOR"). */
    Optional<Rol> findByNombre(String nombre);
}