package uts.edu.java.proyecto.controlador;

import uts.edu.java.proyecto.dto.RegistroDTO;
import uts.edu.java.proyecto.servicio.UsuarioServicio;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    @Autowired
    private UsuarioServicio usuarioService;

    // ─────────────────────────────────────────────────────────────────────
    //  LOGIN
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Muestra la página de inicio de sesión.
     * Spring Security maneja el POST /login automáticamente.
     */
    @GetMapping("/login")
    public String login() {
        return "auth/login";   // → templates/auth/login.html
    }

    // ─────────────────────────────────────────────────────────────────────
    //  REGISTRO
    // ─────────────────────────────────────────────────────────────────────

    /** Muestra el formulario de registro. */
    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("registroDTO", new RegistroDTO());
        return "auth/registro";   // → templates/auth/registro.html
    }

    /** Procesa el formulario de registro. */
    @PostMapping("/registro")
    public String registrar(
            @Valid @ModelAttribute("registroDTO") RegistroDTO dto,
            BindingResult result,
            Model model,
            RedirectAttributes flash) {

        // 1. Validaciones de Bean Validation (@NotBlank, @Email, @Size…)
        if (result.hasErrors()) {
            return "auth/registro";
        }

        // 2. Contraseñas coinciden
        if (!dto.contrasenasCoinciden()) {
            model.addAttribute("errorContrasena", "Las contraseñas no coinciden.");
            return "auth/registro";
        }

        // 3. Correo no duplicado
        if (usuarioService.existeCorreo(dto.getCorreo())) {
            model.addAttribute("errorCorreo", "Este correo ya está registrado en el sistema.");
            return "auth/registro";
        }

        // 4. Guardar usuario (con hash bcrypt y rol CAJERO)
        usuarioService.registrar(dto);
        flash.addFlashAttribute("mensajeExito", "¡Registro exitoso! Ya puedes iniciar sesión.");
        return "redirect:/login";
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DASHBOARD (página principal tras login)
    // ─────────────────────────────────────────────────────────────────────

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";   // → templates/dashboard.html
    }
}
