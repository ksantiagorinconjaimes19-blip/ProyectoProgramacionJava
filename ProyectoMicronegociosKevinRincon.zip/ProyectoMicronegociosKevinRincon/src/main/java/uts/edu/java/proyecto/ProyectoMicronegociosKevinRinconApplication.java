package uts.edu.java.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoMicronegociosKevinRinconApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoMicronegociosKevinRinconApplication.class, args);
	}

}
