package uts.edu.java.proyecto.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 80)
    @Column(nullable = false, length = 80)
    private String nombre;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "Ingresa un correo electrónico válido")
    @Column(nullable = false, unique = true, length = 100)
    private String correo;

    // En BD se guarda el hash bcrypt; en el form viene la clave en texto plano
    @NotBlank(message = "La contraseña es obligatoria")
    @Column(nullable = false, length = 255)
    private String contrasena;

    @Column(length = 15)
    private String telefono;

    @Column(nullable = false)
    private Boolean activo = true;

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_rol", nullable = false)
    private Rol rol;

    public Usuario() {}

    // ── Getters & Setters ──────────────────────────────────────────────────
    public Integer       getIdUsuario()                     { return idUsuario; }
    public void          setIdUsuario(Integer id)           { this.idUsuario = id; }

    public String        getNombre()                        { return nombre; }
    public void          setNombre(String nombre)           { this.nombre = nombre; }

    public String        getCorreo()                        { return correo; }
    public void          setCorreo(String correo)           { this.correo = correo; }

    public String        getContrasena()                    { return contrasena; }
    public void          setContrasena(String contrasena)   { this.contrasena = contrasena; }

    public String        getTelefono()                      { return telefono; }
    public void          setTelefono(String telefono)       { this.telefono = telefono; }

    public Boolean       getActivo()                        { return activo; }
    public void          setActivo(Boolean activo)          { this.activo = activo; }

    public LocalDateTime getFechaRegistro()                 { return fechaRegistro; }
    public void          setFechaRegistro(LocalDateTime f)  { this.fechaRegistro = f; }

    public Rol           getRol()                           { return rol; }
    public void          setRol(Rol rol)                    { this.rol = rol; }
}
