package uts.edu.java.proyecto.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                // 1. Permitimos que cualquiera entre al login, al registro y a los estilos CSS/JS
                .requestMatchers("/login", "/registro", "/css/**", "/js/**").permitAll()
                // 2. Cualquier otra ruta (como el dashboard) requerirá haber iniciado sesión
                .anyRequest().authenticated()
            )
            .formLogin(login -> login
                // 3. AQUÍ LE DECIMOS A SPRING QUE USE NUESTRA RUTA PROPIA DE LOGIN
                .loginPage("/login") 
                // 4. Mapeamos los campos del formulario HTML (name="correo" y name="contrasena")
                .usernameParameter("correo")
                .passwordParameter("contrasena")
                // 5. Si el inicio de sesión es correcto, lo mandamos al dashboard
                .defaultSuccessUrl("/dashboard", true)
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}