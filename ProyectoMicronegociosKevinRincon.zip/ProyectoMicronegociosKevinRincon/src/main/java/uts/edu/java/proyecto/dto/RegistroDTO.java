package uts.edu.java.proyecto.dto;

import jakarta.validation.constraints.*;

/**
 * DTO (Data Transfer Object) para el formulario de registro.
 * Permite validar la confirmación de contraseña sin mezclarla con la entidad Usuario.
 */
public class RegistroDTO {

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 80, message = "El nombre no puede exceder 80 caracteres")
    private String nombre;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "Ingresa un correo electrónico válido")
    private String correo;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String contrasena;

    @NotBlank(message = "Debes confirmar tu contraseña")
    private String confirmarContrasena;

    @Size(max = 15, message = "El teléfono no puede exceder 15 caracteres")
    private String telefono;

    // ── Getters & Setters ──────────────────────────────────────────────────
    public String getNombre()                            { return nombre; }
    public void   setNombre(String nombre)               { this.nombre = nombre; }

    public String getCorreo()                            { return correo; }
    public void   setCorreo(String correo)               { this.correo = correo; }

    public String getContrasena()                        { return contrasena; }
    public void   setContrasena(String contrasena)       { this.contrasena = contrasena; }

    public String getConfirmarContrasena()               { return confirmarContrasena; }
    public void   setConfirmarContrasena(String c)       { this.confirmarContrasena = c; }

    public String getTelefono()                          { return telefono; }
    public void   setTelefono(String telefono)           { this.telefono = telefono; }

    /** @return true si ambas contraseñas coinciden */
    public boolean contrasenasCoinciden() {
        return contrasena != null && contrasena.equals(confirmarContrasena);
    }
}
