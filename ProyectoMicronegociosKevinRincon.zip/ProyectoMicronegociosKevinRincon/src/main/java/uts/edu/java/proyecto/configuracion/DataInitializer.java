package uts.edu.java.proyecto.configuracion;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import uts.edu.java.proyecto.modelo.Rol;
import uts.edu.java.proyecto.modelo.Usuario;
import uts.edu.java.proyecto.repositorio.RolRepositorio;
import uts.edu.java.proyecto.repositorio.UsuarioRepositorio;

import java.util.Optional;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RolRepositorio rolRepositorio;
    private final UsuarioRepositorio usuarioRepositorio;
    private final PasswordEncoder passwordEncoder;

    // Inyección por constructor
    public DataInitializer(RolRepositorio rolRepositorio, 
                           UsuarioRepositorio usuarioRepositorio, 
                           PasswordEncoder passwordEncoder) {
        this.rolRepositorio = rolRepositorio;
        this.usuarioRepositorio = usuarioRepositorio;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // 1. Crear los roles si no existen
        Rol rolAdmin = obtenerOCrearRol("ADMINISTRADOR");
        Rol rolCajero = obtenerOCrearRol("CAJERO");
        Rol rolReparto = obtenerOCrearRol("REPARTO");

        // 2. Crear los usuarios de prueba con contraseñas encriptadas
        crearUsuarioSiNoExiste("admin@micronegocio.co", "Admin123", "Administrador Principal", rolAdmin);
        crearUsuarioSiNoExiste("cajero@micronegocio.co", "Caja123", "Cajero de Turno", rolCajero);
        crearUsuarioSiNoExiste("reparto@micronegocio.co", "Repa123", "Repartidor Logístico", rolReparto);
    }

    private Rol obtenerOCrearRol(String nombreRol) {
        return rolRepositorio.findByNombre(nombreRol).orElseGet(() -> {
            Rol nuevoRol = new Rol();
            nuevoRol.setNombre(nombreRol);
            nuevoRol.setDescripcion("Rol de tipo " + nombreRol);
            return rolRepositorio.save(nuevoRol);
        });
    }

    private void crearUsuarioSiNoExiste(String correo, String contrasenaPlana, String nombre, Rol rol) {
        Optional<Usuario> usuarioOpt = usuarioRepositorio.findByCorreo(correo);
        
        if (usuarioOpt.isEmpty()) {
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setCorreo(correo);
            // CRUCIAL: Encriptar la contraseña antes de guardarla
            nuevoUsuario.setContrasena(passwordEncoder.encode(contrasenaPlana));
            nuevoUsuario.setRol(rol);
            
            usuarioRepositorio.save(nuevoUsuario);
            System.out.println("Usuario predeterminado creado con éxito: " + correo);
        }
    }
}